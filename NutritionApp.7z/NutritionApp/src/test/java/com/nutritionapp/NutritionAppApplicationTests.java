package com.nutritionapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.nutritionapp.entity.Nutrition;
import com.nutritionapp.repository.NutritionDao;
import com.nutritionapp.service.NutritionService;

@SpringBootTest
class NutritionAppApplicationTests {
	@MockBean
	NutritionDao dao;
	@Autowired
	NutritionService service;

	@Test
	void testChangeNutrition() {
		Nutrition nutrition = new Nutrition(7,"carnism", "Medium", 800);
		Mockito.when(dao.save(nutrition)).thenReturn(nutrition);
		Nutrition napp = service.ChangeNutrition(nutrition);
		assertEquals(napp, nutrition);

	}

	@Test
	void testCreateNutrition() {
		Nutrition nutrition = new Nutrition(4,"carnism", "Medium", 800);
		Mockito.when(dao.save(nutrition)).thenReturn(nutrition);
		Nutrition napp = service.ChangeNutrition(nutrition);
		assertEquals(napp, nutrition);

	}

	@Test
	void testFindAllNutrition() {
		List<Nutrition> napp = new ArrayList<Nutrition>();
		Mockito.when(dao.findAll()).thenReturn(napp);
		List<Nutrition> napp1 = service.findAllplans();
		assertEquals(napp1, napp);
	}

	@Test
	void testRemoveNutrition() {
		Nutrition nutrition = new Nutrition(6,"carnism", "Medium", 800);
		service.RemoveNutrition(nutrition.getId());
		verify(dao,times(1)).deleteById(nutrition.getId());
	}

	@Test
	void testGetNutrition() {
		Nutrition nutrition = new Nutrition(3,"carnism", "Medium", 800);
		Optional<Nutrition> napp1 = Optional.of(nutrition);
		Mockito.when(dao.findById(nutrition.getId())).thenReturn(napp1);
		Optional<Nutrition> napp = service.getNutrition(nutrition.getId());
		assertEquals(napp, napp1);
		
	}

	@Test
	void testFindAllByName() {
		List<Nutrition> napp = new ArrayList<Nutrition>();
		Mockito.when(dao.findAllByName("carnism")).thenReturn(napp);
		assertFalse(napp.size() > 0);

	}

}





















// List<Nutrition> napp = service.findAll();
// assertFalse(napp.size() > 0);

//	@Test
//	void testRemoveNutrition() {
//		Nutrition nutrition = new Nutrition(747, "Fluffy", "Medium", 500.0f);
//		//Mockito.verify(dao).deleteById(747);
//		String napp1 = service.RemoveNutrition(747);
//		assertEquals(napp1, 747);
//	}

//@Test
//void testDeleteNutrition() {
//	Nutrition nutrition = new Nutrition(747,"Fluffy","Medium", 500.0f);
//	service.delete(nutrition.getNutritionIdentification());
//}
