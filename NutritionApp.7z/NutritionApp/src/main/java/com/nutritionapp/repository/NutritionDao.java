package com.nutritionapp.repository;

import java.util.List;




import org.springframework.data.jpa.repository.JpaRepository;


import com.nutritionapp.entity.Nutrition;

public interface NutritionDao extends JpaRepository<Nutrition , Integer>{

	
	List<Nutrition> findAllByName(String name);




}

