package com.nutritionapp.service;

import java.util.List;


import java.util.Optional;

import com.nutritionapp.entity.Nutrition;

public interface NutritionService {

	Nutrition CreateNutrition(Nutrition nutritionplan);

	Nutrition ChangeNutrition(Nutrition nutritionplan);

	String RemoveNutrition(int Id);

	List<Nutrition> findAllplans();


	Optional<Nutrition> getNutrition(int nId);

	List<Nutrition> findAllByName(String name);

	

	

	


	
}

