
package com.nutritionapp.service;

import java.util.List;


import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nutritionapp.entity.Nutrition;
import com.nutritionapp.repository.NutritionDao;

@Service
@Transactional

public class NutritionServiceImpl implements NutritionService {

	@Autowired

	NutritionDao dao;

	@Override
	public Nutrition ChangeNutrition(Nutrition nutritionplan) {

		return dao.save(nutritionplan);
	}

	@Override
	public Nutrition CreateNutrition(Nutrition nutritionplan) {

		return dao.save(nutritionplan);// save(), persist();
	}

	@Override
	public List<Nutrition> findAllplans() {

		return dao.findAll();
	}

	@Override
	public String RemoveNutrition(int Id) {
		dao.deleteById(Id);
		return "deleted Succesfully";
	}

//	@Override
//	public Optional<Nutrition> ChangeNutrition(int nId) {

//		return Optional.of(dao.getById(nId));
//	}

	@Override
	public Optional<Nutrition> getNutrition(int nId) {

		return dao.findById(nId);
	}

	@Override
	public List<Nutrition> findAllByName(String name) {
		return dao.findAllByName(name);
	}


}
