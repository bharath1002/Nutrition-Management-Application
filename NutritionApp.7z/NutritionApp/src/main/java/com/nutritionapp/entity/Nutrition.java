package com.nutritionapp.entity;

import java.sql.Date;



import java.time.LocalDate;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Positive;

@SuppressWarnings("unused")
@Entity
@Table(name = "NutritionData")

public class Nutrition {

	@Id
	@Column(name = "nid", length = 10)
//	@Positive(message = "Id should be positive number")
//	@GeneratedValue
	private int Id;
	
	@Column(name = "name", length = 15)
	@NotBlank(message = "name is mandatory")
	private String name;
	
	@Column(name = "description", length = 25)
	@NotBlank(message="planDescription cannot be empty")
	private String planDescription;
	
	@Column(name = "CreatedAt", length = 10)
	private LocalDate created_At=LocalDate.now();
	
	@Column(name = "UpdatedAt", length = 10)
	private LocalDate updated_At=LocalDate.now();
	
	@Column(name = "price", length = 15)
	private long price;

	public Nutrition() {

	}

	public Nutrition(int Id,String name, String planDescription, long price) {
		super();
		this.Id = Id;
		this.name = name;
		this.planDescription = planDescription;
		this.price = price;
	}

	public int getId() {
		return Id;
	}

	public void setId(int Id) {
		this.Id = Id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPlanDescription() {
		return planDescription;
	}

	public void setPlanDescription(String planDescription) {
		this.planDescription = planDescription;
	}


	public LocalDate getCreated_At() {
		return created_At;
	}

	public void setCreated_At(LocalDate created_At) {
		this.created_At = created_At;
	}

	
	public LocalDate getUpdated_At() {
		return updated_At;
	}

	public void setUpdated_At(LocalDate updated_At) {
		this.updated_At = updated_At;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Nutrition [Id=" + Id + ", name=" + name + ", planDescription=" + planDescription + ", created_At="
				+ created_At + ", updated_At=" + updated_At + ", price=" + price + "]";
	}

}
