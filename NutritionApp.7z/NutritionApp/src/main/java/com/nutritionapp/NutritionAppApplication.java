package com.nutritionapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The Class NutritionAppApplication.
 */
@SpringBootApplication // same as @Configuration @EnableAutoConfiguration @ComponentScan
public class NutritionAppApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(NutritionAppApplication.class, args);
	}

}
