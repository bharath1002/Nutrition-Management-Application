package com.nutritionapp.controller;

import java.util.List;





import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.nutritionapp.entity.Nutrition;
import com.nutritionapp.exception.NutritionIdAlreadyExistsException;

import com.nutritionapp.exception.NutritionPlanIdNotFoundException;
import com.nutritionapp.exception.RecordNotFoundException;
import com.nutritionapp.exception.NutritionNameNotFoundException;
import com.nutritionapp.service.NutritionService;

@RestController
@RequestMapping("/nutrition")
public class NutritionController {

	@Autowired
	NutritionService service;

	@PostMapping("/createplan") // http://localhost:8520/nutrition/createplan
	public Nutrition createNutrition(@Valid @RequestBody Nutrition napp) throws NutritionIdAlreadyExistsException {
		 int id = napp.getId();
		 Optional<Nutrition> nap = service.getNutrition(id);
		if (nap.isPresent()) {
			throw new NutritionIdAlreadyExistsException("Given Id already exist to creat new plan");

		} else {
			return service.CreateNutrition(napp);

		}

	}

	@PutMapping("/changeplan")
	public Nutrition changeNutrition(@Valid @RequestBody Nutrition napp) throws NutritionPlanIdNotFoundException {
	 int id = napp.getId();
	 Optional<Nutrition> nap = service.getNutrition(id);
		if (nap.isPresent()) {
			return service.ChangeNutrition(napp);
		} else {

			throw new NutritionPlanIdNotFoundException("the given Id is not found");
		}

	}

	@GetMapping("/getNutrition/{nid}")
	public Nutrition getNutrition(@Valid @PathVariable("nid") int nId) throws NutritionPlanIdNotFoundException {

		Optional<Nutrition> napp = service.getNutrition(nId);
		if (napp.isPresent()) {
			return napp.get();
		} else {
			throw new NutritionPlanIdNotFoundException("with the given id employee not found");
		}
	}

	
	@GetMapping("/findallbyname/{name}")
	public List<Nutrition> findAllByName(@Valid @PathVariable("name") String name) throws NutritionNameNotFoundException {
	List<Nutrition> napp = service.findAllByName(name);	
	if (napp == null) {
		throw new NutritionNameNotFoundException("given name is not found in the nutritionplan ");
		
		
	} else {
		return napp;
	}
	}
	

	
	@GetMapping("/findallPlans")
	public List<Nutrition> findAllplans() throws RecordNotFoundException { 
		List<Nutrition> list = service.findAllplans();
		if(list.size() == 0) {
			throw new RecordNotFoundException("there is no record for given list");
		} else {
		return list;
	}
		
	}

	@DeleteMapping("deleteplan/{Id}")
	public String removeNutrition(@Valid @PathVariable("Id") int Id) throws NutritionPlanIdNotFoundException {
		Optional<Nutrition> napp = service.getNutrition(Id);
		if(napp.isPresent()) {
			return service.RemoveNutrition(Id);
		} else {
			throw new NutritionPlanIdNotFoundException("id not found ");
		}
		
	}
	
	
	

}

