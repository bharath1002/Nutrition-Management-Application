package com.nutritionapp.exception;

public class NutritionPlanIdNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;
	public NutritionPlanIdNotFoundException(String message) {

		super(message);
	}

}
