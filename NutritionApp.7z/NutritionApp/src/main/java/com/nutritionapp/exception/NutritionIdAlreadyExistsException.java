package com.nutritionapp.exception;

@SuppressWarnings("serial")
public class NutritionIdAlreadyExistsException extends Exception {

	@SuppressWarnings("unused")
	private static long serialVersionUID = 1L;
	public NutritionIdAlreadyExistsException(String message) {

		super(message);

	}

}
